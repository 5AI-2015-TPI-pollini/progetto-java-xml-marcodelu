# DeluWeather
## What is
DeluWather is the result of a task assigned by Prof. Pollini Andrea for the school year 2015/16.
It's a program that checks the weather for an address inserted by the user.

## How does it work
DeluWeather works using Google Maps and OpenWeather APIs for retrieving data in XML, after it shows the result on screen using JavaFX.

## Links
Wiki:     http://github.com/5AI-2015-TPI-pollini/progetto-java-xml-marcodelu/wiki

Web Site: http://5ai-2015-tpi-pollini.github.io/progetto-java-xml-marcodelu/

##Author
Marco De Lucchi
marcodelucchi27@gmail.com